# MowerFix AI V2

## What's new
- Husqvarna + Segway Navimow focused model master data
- 100+ manufacturer-supported diagnostic mappings generated from verified model/fault relationships
- Exact error-code/message lookup
- Manufacturer source link on every verified matrix record
- Decision-tree presentation before part recommendation
- Genuine-part mapping where a manufacturer-supported relationship exists
- Supplier and price fields are separate from manufacturer verification
- Local anonymous test feedback
- Print-friendly diagnosis
- Mobile responsive UI

## Stripe
V2 defaults to free testing so you can verify the database locally.
To enable the €4.99 payment gate, open `app.js` and change:
`paymentRequired:false`
to:
`paymentRequired:true`
Then set `paymentLink` to your Stripe Payment Link.

## Run
Open `index.html` in a browser, or upload the entire folder to your web host.

## Data quality rule
The UI promotes only records marked `verification:'manufacturer'` as verified. Community-only error-code references from earlier builds are not promoted into the verified lookup.
